#pragma once 

#include "Sock.hpp"
#include "Protocol.hpp"

#include <pthread.h>
#define DEFPORT 8080 //默认端口号

class HttpServer
{
private:
    int port;
    int lsock;
public:
    HttpServer(int _port = DEFPORT):port(_port)
    {}
    
    //初始化--创建套接字相关
    void Init()
    {
        //创建套接字
        lsock = Sock::Socket();
        //设置端口复用
        Sock::Setsockopt(lsock);
        //绑定
        Sock::Bind(lsock,port);
        //监听
        Sock::Listen(lsock);
    }
    
    void Start()
    {
        for(;;)
        {
            int sock = Sock::Accept(lsock);
            if(sock < 0)
                continue;
            
            //创建线程，处理请求
            pthread_t pid;
            int* sockp = new int(sock);
            pthread_create(&pid,nullptr,Entry::HandlerHttp,sockp);

            pthread_detach(pid);
        }
    }

    ~HttpServer()
    {
        //关闭打开的文件描述符
        if(lsock >= 0)  
            close(lsock);
    }
};
