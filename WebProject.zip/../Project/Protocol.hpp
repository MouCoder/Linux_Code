#pragma once
#include "Log.hpp"
#include "Sock.hpp"

class Request
{};

class Response
{};

class Entry
{
private:
    Request req;
    Response rsp;
public:
    static void* HandlerHttp(void* arg)
    {
        int sock = *((int*)arg);
        delete (int*)arg;

#ifdef DEBUG 
        char buffer[10240] = {0};

        recv(sock,buffer,sizeof(buffer),0);

        std::cout<<buffer<<std::endl;
        close(sock);
#else 
        std::cout<<"test"<<std::endl;
#endif
        return nullptr;
    }
};
