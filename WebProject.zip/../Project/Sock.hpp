#pragma once 

/*创建套接字相关接口*/

#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <strings.h>
#include "Log.hpp"

#define MAXLISTEN 5

class Sock
{
public:
    //创建套接字
    static int Socket()
    {
        int lsock = socket(AF_INET,SOCK_STREAM,0);

        //创建失败--退出进程
        if(lsock < 0)
        {
            //生成日志
            LOG(Fatal,"soecket error"); 
            //退出进程
            exit(1);
        }

        return lsock;
    }
    //将端口号port绑定到sock中
    static void Bind(int sock,int port)
    {
        struct sockaddr_in local;
        bzero(&local,SocketErr);

        local.sin_family = AF_INET;
        local.sin_port = htons(port);
        local.sin_addr.s_addr = INADDR_ANY;

        //绑定
        if(bind(sock,(struct sockaddr*)&local,sizeof(local)) < 0)
        {
            //绑定失败
            LOG(Fatal,"Bind error");
            exit(BindErr);
        }
    }
    //监听
    static void Listen(int sock)
    {
        int s = listen(sock,MAXLISTEN);

        if(s < 0)
        {
            LOG(Fatal,"listen error");
            exit(ListenErr);
        }
    }

    static void Setsockopt(int sock)
    {
        int opt = 1;
        setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
    }

    static int Accept(int sock)
    {
        struct sockaddr_in rem;
        socklen_t len = sizeof(rem);
        int s = accept(sock,(struct sockaddr*)&rem,&len);

        if(s < 0)
        {
            LOG(Warning,"accept error");
        }

        return s;
    }
};

