#include "HttpServer.hpp"
#include "Log.hpp"

int main(int argc,char* argv[])
{
    HttpServer* hps = new HttpServer();

    hps->Init();
    hps->Start();
    return 0;
}
